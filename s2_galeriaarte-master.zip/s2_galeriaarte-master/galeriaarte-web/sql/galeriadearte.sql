delete from GaleriaEntity;

